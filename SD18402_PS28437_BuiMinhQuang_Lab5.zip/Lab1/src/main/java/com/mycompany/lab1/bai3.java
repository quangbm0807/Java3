/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author buimi
 */
public class bai3 {

    public static void main(String[] args) {
        JFrame signUp = new JFrame("Sign up form");
        signUp.setSize(350, 220);
        JLabel lblUsername = new JLabel("Username");
        lblUsername.setBounds(10, 15, 100, 20);
        JLabel lblPassword = new JLabel("PassWord");
        lblPassword.setBounds(10, 50, 100, 20);
        JLabel lblConfirm = new JLabel("Confirm");
        lblConfirm.setBounds(10, 85, 100, 20);
        JTextField txtUserName = new JTextField();
        txtUserName.setBounds(110, 15, 200, 20);
        JPasswordField txtPassWord = new JPasswordField();
        txtPassWord.setBounds(110, 50, 200, 20);
        JPasswordField txtConfirm = new JPasswordField();
        txtConfirm.setBounds(110, 85, 200, 20);
        JButton btnSignUp = new JButton("Sign Up");
        btnSignUp.setBounds(110, 125, 90, 40);
        JButton btnCancel = new JButton("Cancel");
        btnCancel.setBounds(220, 125, 90, 40);
        btnSignUp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = txtUserName.getText();
                char[] password = txtPassWord.getPassword();
                char[] confirm = txtConfirm.getPassword();
                if (username.isEmpty() || password.length == 0 || confirm.length == 0) {
                    JOptionPane.showMessageDialog(signUp, "Vui lòng nhập đầy đủ thông tin!");
                } else if (!Arrays.equals(password, confirm)) {
                    JOptionPane.showMessageDialog(signUp, "Xác nhận mật khẩu không đúng!");
                } else {
                    JOptionPane.showMessageDialog(signUp, "Đăng ký thành công!");
                }
            }
        });
        btnCancel.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        signUp.add(lblUsername);
        signUp.add(lblPassword);
        signUp.add(lblConfirm);
        signUp.add(txtUserName);
        signUp.add(txtPassWord);
        signUp.add(txtConfirm);
        signUp.add(btnSignUp);
        signUp.add(btnCancel);
        signUp.setLayout(null);
        signUp.setLocationRelativeTo(null);
        signUp.setDefaultCloseOperation(signUp.EXIT_ON_CLOSE);
        signUp.setVisible(true);
    }

}
