/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author buimi
 */
public class bai2 {

    public static void main(String[] args) {
        JFrame cal = new JFrame("Calculator");
        JLabel lblFirst = new JLabel("First Number: ");
        lblFirst.setBounds(10, 10, 100, 20);

        JLabel lblSecond = new JLabel("Second Number: ");
        lblSecond.setBounds(10, 40, 100, 20);

        JLabel lblResult = new JLabel("Result: ");
        lblResult.setBounds(10, 70, 100, 20);

        JTextField txtFirst = new JTextField();
        txtFirst.setBounds(130, 10, 150, 20);

        JTextField txtSecond = new JTextField();
        txtSecond.setBounds(130, 40, 150, 20);

        JTextField txtResult = new JTextField();
        txtResult.setBounds(130, 70, 150, 20);

        JButton btnCong = new JButton("+");
        btnCong.setBounds(35, 100, 50, 50);

        JButton btnTru = new JButton("-");
        btnTru.setBounds(95, 100, 50, 50);

        JButton btnNhan = new JButton("*");
        btnNhan.setBounds(155, 100, 50, 50);

        JButton btnChia = new JButton("/");
        btnChia.setBounds(215, 100, 50, 50);

        btnCong.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double firstNumber = Double.parseDouble(txtFirst.getText());
                    double secondNumber = Double.parseDouble(txtSecond.getText());
                    double result = firstNumber + secondNumber;
                    txtResult.setText(String.valueOf(result));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(cal, "Vui lòng nhập số hợp lệ.");
                }
            }
        });

        btnTru.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double firstNumber = Double.parseDouble(txtFirst.getText());
                    double secondNumber = Double.parseDouble(txtSecond.getText());
                    double result = firstNumber - secondNumber;
                    txtResult.setText(String.valueOf(result));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(cal, "Vui lòng nhập số hợp lệ.");
                }
            }
        });

        btnNhan.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double firstNumber = Double.parseDouble(txtFirst.getText());
                    double secondNumber = Double.parseDouble(txtSecond.getText());
                    double result = firstNumber * secondNumber;
                    txtResult.setText(String.valueOf(result));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(cal, "Vui lòng nhập số hợp lệ.");
                }
            }
        });

        btnChia.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double firstNumber = Double.parseDouble(txtFirst.getText());
                    double secondNumber = Double.parseDouble(txtSecond.getText());
                    double result = firstNumber / secondNumber;
                    txtResult.setText(String.valueOf(result));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(cal, "Vui lòng nhập số hợp lệ.");
                }
            }
        });

        cal.add(lblFirst);
        cal.add(lblSecond);
        cal.add(lblResult);
        cal.add(txtFirst);
        cal.add(txtSecond);
        cal.add(txtResult);
        cal.add(btnCong);
        cal.add(btnTru);
        cal.add(btnNhan);
        cal.add(btnChia);
        cal.setSize(300, 220);
        cal.setLayout(null);
        cal.setLocationRelativeTo(null);
        cal.setDefaultCloseOperation(cal.EXIT_ON_CLOSE);
        cal.setVisible(true);
    }
}
